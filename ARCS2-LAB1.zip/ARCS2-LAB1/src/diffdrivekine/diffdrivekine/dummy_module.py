#!/usr/bin/python3

dummy_var = 0

def dummy_function():
    pass